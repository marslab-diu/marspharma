
/**
 * @author Minhazul Abedin
 *         ID: 221-15-4919
 */
package dao;

public class PharmacyUtils {
    public static String billPath = "D:\\";
    
}
